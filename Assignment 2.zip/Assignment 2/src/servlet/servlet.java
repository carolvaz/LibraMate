package servlet;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.tools.JavaFileObject;

import netscape.javascript.JSObject;


@WebServlet("/servlet")
public class servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String url = "https://www.googleapis.com/books/v1/volumes?q=";

    public servlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void sendGet() throws Exception {
    	//make api call, you get a json from the api call
		
    		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		int responseCode = con.getResponseCode();

		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//print result
		System.out.println(response.toString());

	}
    
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String next = "displayPage.jsp";
		PrintWriter out = response.getWriter();
		
		String search = request.getParameter("book");
		String opt = request.getParameter("opt");
		//String page = null;
		
		System.out.println(search); //prints out what was searched
		
		//url=url+URLEncoder.encode(search, "UTF-8")+"&maxResults=12"; //encoding URL
		//System.out.println(url);
		
		//make call to google books api
		
		for(int i=0; i<search.length(); i++) {
			if(search.charAt(i)==' ') {
				url=url+URLEncoder.encode(search, "UTF-8")+"&maxResults=12"; //encoding URL
				System.out.println(url);
			}
			if(search == " ") {
				next = "/homePage.jsp";
				request.setAttribute("searchError", "Must include search opt." );
			}
			//radio buttons
			if(opt == "Title") {
				search="intitle:"+search;
			}
			else if(opt == "ISBN") {
				search="isbn:"+search;
			}
			else if(opt == "Author") {
				search="inauthor:"+search;
			}
			else if(opt == "Genre") {
				search="subject:"+search;
			}
		}
		
		request.setAttribute("book", search);

		response.sendRedirect(next);
		
		
	}

}
